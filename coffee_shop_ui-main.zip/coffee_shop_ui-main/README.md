# coffee_shop_ui

Coffee Shop App  
https://www.figma.com/community/file/1116708627748807811

[Tutorial](https://youtu.be/OBSRvwM729k)

|                         Onboarding                         |                         Home                         |                         Detail                         |
| :--------------------------------------------------------: | :--------------------------------------------------: | :----------------------------------------------------: |
| <img src="screenshot/onboarding.png" style="height:450px"> | <img src="screenshot/home.png" style="height:450px"> | <img src="screenshot/detail.png" style="height:450px"> |
