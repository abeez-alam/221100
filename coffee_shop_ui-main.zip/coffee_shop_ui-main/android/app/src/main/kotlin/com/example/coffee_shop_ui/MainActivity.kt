package com.example.coffee_shop_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
