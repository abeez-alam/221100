import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from "react-router-dom";

const Read = () => {

    const [apiData, setapiData] = useState([])
    function getdata(){
        axios.get("https://66dd709ff7bcc0bbdcde1ccb.mockapi.io/crud")
        .then((response)=>{
               setapiData(response.data)
        })
    }
    function handleDelete(id){
      axios.delete(`https://66dd709ff7bcc0bbdcde1ccb.mockapi.io/crud/${id}`)
      .then(() =>{
        getdata();
      })
    }
    function setDataToStorage(id,name,age,email){
        localStorage.setItem('id',id);
        localStorage.setItem('name',name);
        localStorage.setItem('age',age);
        localStorage.setItem('email',email);

    }
    useEffect(() => {
      getdata();
    }, [])
    
  return (
   <>
   <div className="row">
    <div className="col-md-12">
        <div className="mb-2 mt-2">
         <Link to='/create'>
         <button className='btn btn-primary' >create</button>
         </Link>
        </div>
        <table className='table table-bordered table-striped table-dark table-hover' >
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>AGE</th>
                    <th>EMAIL</th>
                    <th>DELETE</th>
                    <th>UPDATE</th>
                </tr>
            </thead>
            <tbody>
                {
                    apiData.map((items) =>{
                     return (
                        <>
             <tr>
                    <td>{items.id}</td>
                    <td>{items.e_name}</td>
                    <td>{items.e_age}</td>
                    <td>{items.e_email}</td>
                    <td>
                        <button className='btn btn-danger' onClick={() => {
                            if(window.confirm("are you sure to delete data??"))
                            {
                                handleDelete(items.id)
                            }
                        }}>Delete</button>
                    </td>
                    <td>
                        <Link to='/edit'>
                        <button className='btn btn-secondary'onClick={() => setDataToStorage(items.id,items.e_name,items.e_age,items.e_email)}>Update</button>
                        </Link>
                    </td>
                    
                    
                  
                   
                </tr>         
                       </>
                     )
                    })
                }
           
             
          
                    
            </tbody>
        </table>
    </div>
   </div>
   
   
  
   </>
  )
}

export default Read
