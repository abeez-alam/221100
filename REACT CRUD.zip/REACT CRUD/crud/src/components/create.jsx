import axios from "axios";
import { useState } from "react"
import React from 'react'
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";


function Create() {
    const [name, setName] = useState("");
    const [age, setAge] = useState("");
    const [email, setEmail] = useState("");

    const navigate = useNavigate();

    const handlesubmit = (e) =>{
        e.preventDefault();
        axios.post("https://66dd709ff7bcc0bbdcde1ccb.mockapi.io/crud",{
            e_name: name,
            e_age: age,
            e_email: email
        }).then(() => {
            navigate('/');
        })
    }
  return (
 <>
  <h1 className='text-center'>CREATE FORM</h1>
 <div className="container">
 <div className="mb-2 mt-2">
         <Link to='/'>
         <button className='btn btn-primary'>read</button>
         </Link>
        </div>
 <div className="row">
    <div className="col-md-4">
        <form onSubmit={handlesubmit}>
            <div className="form-group">
                <label >Enter Name:</label>
                <input type="text"  placeholder='Enter Name' className='form-control' onChange={(e) =>setName(e.target.value)}/>
            </div>
            <div className="form-group">
                <label >Enter Age:</label>
                <input type="number"  placeholder='Enter Age' className='form-control'onChange={(e) =>setAge(e.target.value)}/>
            </div>
            <div className="form-group">
                <label >Enter Email:</label>
                <input type="Email"  placeholder='Email' className='form-control'onChange={(e) =>setEmail(e.target.value)}/>
            </div>
            <br /><br />
            <div className="d-grid">
            <input type="submit" value="submit" className='btn btn-primary'/>

            </div>
        </form>
      
    </div>
 </div>
 </div>
 


 
 
 </>
  )
}

export default Create

