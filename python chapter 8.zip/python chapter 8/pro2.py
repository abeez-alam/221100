def inch_to_cm(inch):
    return inch * 2.54

n = int(input("enter value in inches:"))
print(f"the corresponding value in cms:{inch_to_cm(n)} ")