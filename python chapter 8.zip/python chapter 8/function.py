# def avg():
#     x = int(input("Enter your first number: "))
#     b = int(input("Enter your second number: "))
#     c = int(input("Enter your third number: "))

#     average = (x + b + c) / 3
#     print( average)

# # Call the function once
# avg()


# def GoodDay(name,int):
#     print("assalam o alaikum" + name)
#     print(int)
# GoodDay("Abeez",22)

def GoodDay(name,last="alam"):
    print(f"assalam o alaikum {name}" + last )
    print(last)
GoodDay("Abeez")
