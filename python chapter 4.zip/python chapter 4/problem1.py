fruits=[]

f1 = input("enter fruit name:")
fruits.append(f1)
f2 = input("enter fruit name:")
fruits.append(f2)
f3 = input("enter fruit name:")
fruits.append(f3)
f4 = input("enter fruit name:")
fruits.append(f4)
f5 = input("enter fruit name:")
fruits.append(f5)
f6 = input("enter fruit name:")
fruits.append(f6)
f7 = input("enter fruit name:")
fruits.append(f7)

print(fruits)