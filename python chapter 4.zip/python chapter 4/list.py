var = ["apple","orange",99.08,90,True,"abeez"]

# print(var[0])

var[0] = "grapes"
print(var[0])
