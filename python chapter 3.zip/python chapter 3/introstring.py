name = "abeez alam"

arrayname = name[0:3]
print(arrayname)