# print("Hello World!")
import pyttsx3
engine = pyttsx3.init()
engine.say("mairaj tum kaam se agaye")
engine.runAndWait()