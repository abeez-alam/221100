import pyjokes

joke =pyjokes.get_joke()
print(joke)