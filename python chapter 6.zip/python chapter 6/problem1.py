a1 = int(input("enter your number"))
a2 = int(input("enter your number"))
a3 = int(input("enter your number"))
a4 = int(input("enter your number"))

if(a1>a2 and a1>a3 and a1>a4):
    print("your number is greater a1", a1)
elif(a2>a1 and a2>a3 and a2>a4):
    print("your number is greater a2",a2)
elif(a3>a2 and a3>a1 and a3>a4):
    print("your number is greater a3",a3) 
elif(a4>a2 and a4>a3 and a4>a1):
    print("your number is greater a4",a4)
