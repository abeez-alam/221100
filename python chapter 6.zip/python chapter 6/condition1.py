a = int(input("enter your age:"))
if(a%2 == 0):
    print("age is even")
if(a>=18):
    print("your are eligible")

elif(a<0):
    print("please enter valid age:")

else:
    print("your are uneligible")

