a = int(input("enter your age:"))

if(a>=18):
    print("your are eligible")

elif(a<0):
    print("please enter valid age:")

else:
    print("your are uneligible")

