English = int(input("enter you english marks:"))
Science = int(input("enter you science marks:"))
Maths = int(input("enter you Maths marks:"))


total_percenteage = (100*(English+Science+Maths))/300

if(total_percenteage >= 40):
    print("you are pass",total_percenteage)
else:
    print("you are fail: fail",total_percenteage)