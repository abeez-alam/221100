import 'dart:io';

// void main(){
//    print("Enter 1 number=");
//    int num1=int.parse(stdin.readLineSync()!);
//      print("Enter 2 number=");
//    int num2=int.parse(stdin.readLineSync()!);
//    int sum=num1+num2;
//    print(sum);
// }
// int main(){
//    print("Enter 1 number=");
//    int num1=int.parse(stdin.readLineSync()!);
//      print("Enter 2 number=");
//    int num2=int.parse(stdin.readLineSync()!);
//    int sum=num1+num2;
//    print(sum);
//    return(sum);
// }
// String main(){
//    print("Enter 1 name=");
//    String num1=stdin.readLineSync()!;
//      print("Enter 2 name=");
//    String num2=stdin.readLineSync()!;
//    String sum=num1+num2;
//    print("my name is $num1  $num2");
//    return(sum);
// }
double main(){
   print("Enter 1 number=");
   double num1=double.parse(stdin.readLineSync()!);
    print("Enter 1 number=");
   double num2=double.parse(stdin.readLineSync()!);
   double sum=num1+num2;
   print(sum);
   return(sum);
}
