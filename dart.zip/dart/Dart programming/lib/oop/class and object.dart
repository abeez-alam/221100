class Addition{
  Add(){
    int a = 20;
    int b = 40;
    int c = a+b;
    print(c);
  }
}
void main(){
  Addition obj = Addition();
  obj.Add();
}