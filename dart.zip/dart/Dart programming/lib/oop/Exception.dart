class Test{
  div(){
  try{
      var x = 5 ~/ 0;
    print(x);
  }
  on IntegerDivisionByZeroException{
    print("error");
  }
  }
}
void main(){
  Test obj =Test();
  obj.div();
}