class Parent{
  parent(){
    print("i am parent");
  }
}
class Daughter extends Parent{
  daughter(){
    print("i am daughter");
  }
}
class Son extends Daughter{
  son(){
    print("i am son");
  }
}
void main(){
  Daughter obj1=Daughter();
  obj1.daughter();
  obj1.parent();

   Son obj2=Son();
  obj2.son();
  obj2.daughter();
}