import 'dart:io';

  class Addition{
  static add(int a,int b){
    int c= a +b;
    print(c);
  }
}