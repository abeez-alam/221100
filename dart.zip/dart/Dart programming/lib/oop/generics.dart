class Test{
  list(){
    List<int> listname = [1,2,3,4,5];
    listname.add(6);
    print(listname);
  }
}
void main(){
  Test obj =Test();
  obj.list();
}