import 'dart:io';

// class Addition{
//   Add(){
//       stdout.write("Enter your first number=");
//   int num1=int.parse(stdin.readLineSync()!);
//    stdout.write("Enter your second number=");
//   int num2=int.parse(stdin.readLineSync()!);
//   int sum=num1+num2;
//   print(sum);
//   }
// }
// void main(){
//   Addition obj = Addition();
//   obj.Add();
// }

// <--parameterconstructor--!>
// class Test{
//   add(int a, int b){
//     int c =a+b;
//     print(c);

//   }
// }
// void main(){
//   Test obj = Test();
//   obj.add(10, 20);
// }
// <--parameterconstructor--!>

class Test{
  add({required int num1, required int num2}){
    int sum = num1+ num2;
    print(sum);

  }
}
void main(){
  Test obj = Test();
  obj.add(num1: 50, num2: 100);
 
}