class A{
   var name;
  void set cusset(String name){
    this.name=name;

  }
  String get cusset{
    return name;
  }
}
void main(){
  A obj =A();
  obj.cusset="abeez";
  print(obj.cusset);
}