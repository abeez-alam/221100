abstract class HumanBeing{
  Eyes();
}
class Male extends HumanBeing{
  Eyes(){
    print("This eyes is important for male");
  }
}
class Female extends HumanBeing{
  Eyes(){
    print("This eyes is important for  Female");
  }
}
void main(){
  Female obj = Female();
  obj.Eyes();
  Male obj1 = Male();
  obj1.Eyes();
}