void main(){
   for(int i=0; i<=10; i++){
    print(i);
   }
   int i = 11;
   while(i <=20){
    print(i);
    i++;

   }
   int x = 21;
   do {
     print(x);
     x++;
   } while (x <= 30);
}