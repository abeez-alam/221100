import 'dart:io';

void main(){
  // print("Enter 1 number=");
  //  int num1=int.parse(stdin.readLineSync()!);
  //    print("Enter 2 number=");
  //  int num2=int.parse(stdin.readLineSync()!);
  //  int sum=num1*num2;
  //  print(sum);
    

  //    print("Enter your name:");
  //  String name =stdin.readLineSync()!;
  //      print("Enter last name:");
  //  String lastname =stdin.readLineSync()!;
  //  String sum =name+lastname;

  //  print(sum);


    //  print("Enter your value=");
    //  double value =double.parse(stdin.readLineSync()!);


    //  print(value);


    // bool value=true;
    // print(value);
}




