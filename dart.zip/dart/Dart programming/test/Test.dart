// class Test{
//   add(){
//     Map<String,String> mapdata ={
//       "id":"1",
//       "Name":"abeez alam",
//       "father name":"masroor alam",
      
//     };
//      print(mapdata);
//   }
 
// }
// void main(){
//   Test obj = Test();
//   obj.add();
// }

import 'package:dart_application2/oop/statickeywords.dart';

class Test {
  test(){
    Addition.add(200,400);
  }
}
void main(){
  Test obj= Test();
  obj.test();
}