import 'dart:io';

void main(){
  stdout.write("1. Enter first choice:");
  int choice =int.parse(stdin.readLineSync()!);

  switch(choice){
    case 1:
     stdout.write("1. Enter first number:");
     int num1 =int.parse(stdin.readLineSync()!);
     stdout.write("2. Enter second number:");
     int num2 =int.parse(stdin.readLineSync()!);
     int sum= num2+num1;
     print(sum);
     break;
      case 2:
     stdout.write("1. Enter first number:");
     int num1 =int.parse(stdin.readLineSync()!);
     stdout.write("2. Enter second number:");
     int num2 =int.parse(stdin.readLineSync()!);
     int sum= num2-num1;
     print(sum);
     break;
      case 3:
     stdout.write("1. Enter first number:");
     int num1 =int.parse(stdin.readLineSync()!);
     stdout.write("2. Enter second number:");
     int num2 =int.parse(stdin.readLineSync()!);
     int sum= num2*num1;
     print(sum);
     break;
      case 4:
     stdout.write("1. Enter first number:");
     int num1 =int.parse(stdin.readLineSync()!);
     stdout.write("2. Enter second number:");
     int num2 =int.parse(stdin.readLineSync()!);
     int sum= num2~/num1;
     print(sum);
     break;
     default:
     print("please Enter correct choice:");

  }
}